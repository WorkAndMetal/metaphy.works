import {
  ArrowRight,
  BadgeCheck,
  CalendarDays,
  Compass,
  Crown,
  MapPinned,
  MessageCircle,
  PhoneCall,
  ShieldCheck,
  Sparkles,
  Stars,
  Users,
} from "lucide-react";

const travelInsights = [
  "Travelers planning Turkey trips prefer local expertise for routes, timings, and hidden spots.",
  "Premium guests value private guiding, flexible planning, and clear communication before arrival.",
  "WhatsApp-first communication shortens decision time and builds trust for international guests.",
];

const signatureTours = [
  {
    title: "Istanbul Heritage & Bosphorus",
    duration: "2-3 days",
    summary:
      "Private Ottoman and Byzantine highlights, curated food stops, and sunset Bosphorus moments.",
  },
  {
    title: "Cappadocia Luxury Escape",
    duration: "2 days",
    summary:
      "Sunrise valleys, boutique cave hotel guidance, artisan ateliers, and photo-ready scenic routes.",
  },
  {
    title: "Aegean Coast Signature Journey",
    duration: "3-5 days",
    summary:
      "Ephesus, Sirince, and premium coastal towns with personalized pacing for couples or families.",
  },
];

const planningFlow = [
  {
    title: "Tell us your dates",
    description: "Message us on WhatsApp with your travel window and city list.",
  },
  {
    title: "Receive a custom plan",
    description: "We share a tailored route, guide style, and day-by-day recommendations.",
  },
  {
    title: "Confirm with our team",
    description: "All confirmations are managed directly with our local operations team.",
  },
  {
    title: "Enjoy Turkey with confidence",
    description: "Your guide supports you on-the-ground for a seamless premium experience.",
  },
];

export default function Home() {
  const fallbackWhatsapp = "905555555555";
  const configuredWhatsapp = (
    process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? fallbackWhatsapp
  ).replace(/\D/g, "");
  const whatsappNumber = configuredWhatsapp || fallbackWhatsapp;
  const whatsappText = encodeURIComponent(
    "Hello Best Guides in Turkey, I would like to plan a private tour."
  );
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${whatsappText}`;

  return (
    <div className="relative isolate overflow-hidden">
      <div className="pointer-events-none absolute inset-0 -z-10 bg-[radial-gradient(circle_at_12%_18%,rgba(56,189,248,0.2),transparent_34%),radial-gradient(circle_at_88%_8%,rgba(250,204,21,0.2),transparent_34%),radial-gradient(circle_at_48%_100%,rgba(139,92,246,0.18),transparent_38%)]" />

      <main className="mx-auto flex w-full max-w-6xl flex-col gap-16 px-6 py-10 md:px-10 lg:py-14">
        <header className="flex items-center justify-between rounded-full border border-white/10 bg-white/5 px-5 py-3 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <div className="rounded-full bg-amber-300/20 p-2 text-amber-200">
              <Compass className="size-4" />
            </div>
            <p className="text-sm font-semibold tracking-wide text-zinc-100">
              Best Guides in Turkey
            </p>
          </div>
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-full bg-emerald-300 px-4 py-2 text-sm font-semibold text-zinc-900 transition hover:bg-emerald-200"
          >
            <MessageCircle className="size-4" />
            WhatsApp
          </a>
        </header>

        <section className="grid items-start gap-8 lg:grid-cols-[1.2fr_0.8fr]">
          <div className="space-y-6">
            <p className="inline-flex items-center gap-2 rounded-full border border-amber-200/30 bg-amber-100/10 px-3 py-1 text-xs font-semibold tracking-[0.18em] text-amber-100 uppercase">
              <Stars className="size-3.5" />
              Premium Turkey Experiences
            </p>
            <h1 className="max-w-3xl text-4xl font-semibold leading-tight text-zinc-50 md:text-6xl">
              Signature guided journeys for travelers who want the best of
              Turkey.
            </h1>
            <p className="max-w-2xl text-lg leading-relaxed text-zinc-300">
              We design private, high-comfort travel plans in Turkey for
              couples, families, and small groups. No website checkout; all
              planning and confirmation happens directly on WhatsApp with our
              team.
            </p>
            <div className="flex flex-wrap gap-3">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-full bg-emerald-300 px-5 py-3 text-sm font-semibold text-zinc-950 shadow-[0_10px_30px_-12px_rgba(52,211,153,0.75)] transition hover:bg-emerald-200"
              >
                Plan via WhatsApp
                <ArrowRight className="size-4" />
              </a>
              <a
                href="#tours"
                className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/5 px-5 py-3 text-sm font-semibold text-zinc-100 transition hover:bg-white/10"
              >
                Explore draft tours
              </a>
            </div>
          </div>

          <div className="rounded-3xl border border-white/10 bg-white/5 p-6 backdrop-blur-md">
            <p className="flex items-center gap-2 text-sm font-medium text-zinc-200">
              <Sparkles className="size-4 text-sky-300" />
              Research-backed positioning
            </p>
            <ul className="mt-4 space-y-4">
              {travelInsights.map((insight) => (
                <li key={insight} className="flex items-start gap-3">
                  <BadgeCheck className="mt-0.5 size-4 shrink-0 text-emerald-300" />
                  <p className="text-sm leading-relaxed text-zinc-300">
                    {insight}
                  </p>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section id="tours" className="space-y-5">
          <h2 className="text-2xl font-semibold text-zinc-50 md:text-3xl">
            Draft signature tours
          </h2>
          <div className="grid gap-4 md:grid-cols-3">
            {signatureTours.map((tour) => (
              <article
                key={tour.title}
                className="rounded-2xl border border-white/10 bg-white/[0.04] p-5 transition hover:-translate-y-0.5 hover:bg-white/[0.07]"
              >
                <p className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-2.5 py-1 text-xs font-medium text-zinc-300">
                  <CalendarDays className="size-3.5" />
                  {tour.duration}
                </p>
                <h3 className="mt-4 text-lg font-semibold text-zinc-100">
                  {tour.title}
                </h3>
                <p className="mt-3 text-sm leading-relaxed text-zinc-300">
                  {tour.summary}
                </p>
              </article>
            ))}
          </div>
        </section>

        <section className="grid gap-4 md:grid-cols-2">
          <article className="rounded-2xl border border-white/10 bg-white/[0.04] p-6">
            <h2 className="flex items-center gap-2 text-xl font-semibold text-zinc-100">
              <Crown className="size-5 text-amber-300" />
              Why premium travelers choose us
            </h2>
            <ul className="mt-4 space-y-3 text-sm text-zinc-300">
              <li className="flex items-start gap-2">
                <Users className="mt-0.5 size-4 text-sky-300" />
                Private guide matching based on interests and pace.
              </li>
              <li className="flex items-start gap-2">
                <MapPinned className="mt-0.5 size-4 text-sky-300" />
                Curated routes with cultural depth and fewer tourist traps.
              </li>
              <li className="flex items-start gap-2">
                <PhoneCall className="mt-0.5 size-4 text-sky-300" />
                Direct WhatsApp communication before and during your trip.
              </li>
            </ul>
          </article>

          <article className="rounded-2xl border border-emerald-200/20 bg-emerald-300/10 p-6">
            <h2 className="flex items-center gap-2 text-xl font-semibold text-zinc-100">
              <ShieldCheck className="size-5 text-emerald-300" />
              Trust and compliance
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-zinc-200">
              We operate with official authorization. TÜRSAB documentation image
              will be added to this section once uploaded.
            </p>
            <div className="mt-4 rounded-xl border border-dashed border-emerald-200/30 bg-emerald-100/10 p-4 text-sm text-emerald-100">
              TÜRSAB license image placeholder
            </div>
          </article>
        </section>

        <section className="space-y-5 rounded-3xl border border-white/10 bg-white/[0.04] p-6">
          <h2 className="text-2xl font-semibold text-zinc-50">
            How planning works
          </h2>
          <div className="grid gap-3 md:grid-cols-2">
            {planningFlow.map((step, index) => (
              <article
                key={step.title}
                className="rounded-xl border border-white/10 bg-white/[0.02] p-4"
              >
                <p className="text-xs font-semibold tracking-[0.16em] text-zinc-400 uppercase">
                  Step {index + 1}
                </p>
                <h3 className="mt-2 text-base font-semibold text-zinc-100">
                  {step.title}
                </h3>
                <p className="mt-1.5 text-sm leading-relaxed text-zinc-300">
                  {step.description}
                </p>
              </article>
            ))}
          </div>
        </section>

        <section
          id="contact"
          className="rounded-3xl border border-white/10 bg-gradient-to-r from-sky-400/20 via-indigo-400/20 to-fuchsia-400/20 p-8"
        >
          <h2 className="text-2xl font-semibold text-zinc-50">
            Start your journey
          </h2>
          <p className="mt-3 max-w-2xl text-zinc-200">
            This website is for premium tour planning and lead collection. No
            online payment is taken here. Contact us on WhatsApp to receive
            your custom route and confirmation details.
          </p>
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-5 inline-flex items-center gap-2 rounded-full bg-emerald-300 px-5 py-3 text-sm font-semibold text-zinc-950 shadow-[0_10px_30px_-12px_rgba(52,211,153,0.75)] transition hover:bg-emerald-200"
          >
            <MessageCircle className="size-4" />
            Contact on WhatsApp
          </a>
        </section>
      </main>
    </div>
  );
}
