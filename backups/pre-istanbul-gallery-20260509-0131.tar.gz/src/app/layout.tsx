import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: {
    default: "Best Guides in Turkey",
    template: "%s | Best Guides in Turkey",
  },
  description:
    "Premium private tour planning in Turkey with expert local guides. Contact us directly on WhatsApp.",
  keywords: [
    "Turkey private tours",
    "Istanbul guide",
    "Cappadocia tour guide",
    "premium turkey travel",
    "Best Guides in Turkey",
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col">{children}</body>
    </html>
  );
}
